import React, { useState } from 'react';
import { Lock, ShieldCheck } from 'lucide-react';

interface AdminLoginProps {
  onLogin: () => void;
}

export const AdminLogin: React.FC<AdminLoginProps> = ({ onLogin }) => {
  const [user, setUser] = useState('');
  const [pass, setPass] = useState('');
  const [error, setError] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // Hardcoded credentials as requested
    if (user === 'admin' && pass === 'sakura4923') {
      onLogin();
    } else if (user === 'ttm1' && pass === 'ttm123') {
        onLogin();
    } else {
      setError('Incorrect username or password');
      setPass('');
    }
  };

  return (
    <div className="flex flex-col items-center justify-center min-h-[50vh] p-4 animate-fade-in-up">
        <div className="bg-white p-6 md:p-8 rounded-2xl shadow-xl border border-slate-200 max-w-sm w-full text-center">
            <div className="w-16 h-16 md:w-20 md:h-20 bg-slate-100 rounded-full flex items-center justify-center mx-auto mb-6 text-slate-500 shadow-inner">
                <Lock size={32} className="md:w-10 md:h-10" />
            </div>
            <h2 className="text-xl md:text-2xl font-bold text-slate-800 mb-2">Restricted Access</h2>
            <p className="text-slate-500 mb-8 text-sm">Administrator credentials required to view this page.</p>
            
            <form onSubmit={handleSubmit} className="space-y-4 text-left">
                <div>
                    <label className="block text-xs font-semibold text-slate-600 mb-1 uppercase tracking-wide">Username</label>
                    <input 
                        type="text" 
                        /* text-base prevents iOS zoom */
                        className="w-full p-3 border border-slate-200 rounded-lg outline-none focus:border-blue-500 focus:ring-2 focus:ring-blue-100 transition-all text-base"
                        value={user}
                        onChange={e => setUser(e.target.value)}
                        autoFocus
                    />
                </div>
                <div>
                    <label className="block text-xs font-semibold text-slate-600 mb-1 uppercase tracking-wide">Password</label>
                    <input 
                        type="password" 
                        className="w-full p-3 border border-slate-200 rounded-lg outline-none focus:border-blue-500 focus:ring-2 focus:ring-blue-100 transition-all text-base"
                        value={pass}
                        onChange={e => setPass(e.target.value)}
                    />
                </div>
                
                {error && (
                    <div className="bg-red-50 text-red-600 text-sm p-3 rounded-lg flex items-center gap-2">
                        <ShieldCheck size={16} /> {error}
                    </div>
                )}

                <button 
                    type="submit"
                    className="w-full py-3.5 bg-slate-900 text-white rounded-xl font-bold hover:bg-slate-800 transition-all transform active:scale-95 shadow-lg mt-4"
                >
                    Authenticate
                </button>
            </form>
        </div>
        <p className="mt-8 text-xs text-slate-400">GeoTime Track Pro • Admin Security</p>
    </div>
  );
};