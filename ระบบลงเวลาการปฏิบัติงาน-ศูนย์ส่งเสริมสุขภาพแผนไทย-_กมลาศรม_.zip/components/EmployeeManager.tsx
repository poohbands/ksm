import React, { useState, useEffect } from 'react';
import { Employee } from '../types';
import { getEmployees, saveEmployee, deleteEmployee } from '../services/storageService';
import { Plus, Trash2, Edit2, User, Save, X } from 'lucide-react';

export const EmployeeManager: React.FC = () => {
  const [employees, setEmployees] = useState<Employee[]>([]);
  const [isEditing, setIsEditing] = useState(false);
  const [formData, setFormData] = useState<Partial<Employee>>({});

  useEffect(() => {
    refreshList();
  }, []);

  const refreshList = () => {
    setEmployees(getEmployees());
  };

  const handleSave = () => {
    if (!formData.name || !formData.position) {
      alert("Name and Position are required");
      return;
    }

    const newEmployee: Employee = {
      id: formData.id || crypto.randomUUID(),
      name: formData.name,
      position: formData.position,
      department: formData.department || 'General',
      status: 'active'
    };

    saveEmployee(newEmployee);
    setIsEditing(false);
    setFormData({});
    refreshList();
  };

  const handleDelete = (id: string) => {
    if (confirm('Are you sure you want to delete this employee?')) {
      deleteEmployee(id);
      refreshList();
    }
  };

  return (
    <div className="bg-white rounded-xl shadow-sm border border-slate-200 overflow-hidden mb-20 md:mb-0">
      <div className="p-4 md:p-6 border-b border-slate-100 flex justify-between items-center bg-slate-50">
        <div>
            <h2 className="text-lg md:text-xl font-bold text-slate-800">Employee Management</h2>
            <p className="text-xs md:text-sm text-slate-500">Manage staff members</p>
        </div>
        {!isEditing && (
          <button 
            onClick={() => setIsEditing(true)}
            className="flex items-center gap-2 bg-blue-600 hover:bg-blue-700 text-white px-3 py-2 md:px-4 md:py-2 rounded-lg transition-colors font-medium shadow-sm text-sm"
          >
            <Plus size={16} /> <span className="hidden md:inline">Add Employee</span><span className="md:hidden">Add</span>
          </button>
        )}
      </div>

      <div className="p-4 md:p-6">
        {isEditing && (
          <div className="mb-8 bg-slate-50 p-4 md:p-6 rounded-xl border border-blue-100 animate-fade-in">
            <h3 className="font-semibold text-lg mb-4 text-slate-800">{formData.id ? 'Edit Employee' : 'New Employee'}</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-1">Full Name</label>
                <input
                  type="text"
                  className="w-full p-3 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none text-base"
                  value={formData.name || ''}
                  onChange={e => setFormData({ ...formData, name: e.target.value })}
                  placeholder="e.g. John Doe"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-1">Position</label>
                <input
                  type="text"
                  className="w-full p-3 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none text-base"
                  value={formData.position || ''}
                  onChange={e => setFormData({ ...formData, position: e.target.value })}
                  placeholder="e.g. Senior Developer"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-1">Department</label>
                <input
                  type="text"
                  className="w-full p-3 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none text-base"
                  value={formData.department || ''}
                  onChange={e => setFormData({ ...formData, department: e.target.value })}
                  placeholder="e.g. Engineering"
                />
              </div>
            </div>
            <div className="flex justify-end gap-3 mt-6">
              <button 
                onClick={() => { setIsEditing(false); setFormData({}); }}
                className="px-4 py-2 text-slate-600 hover:bg-slate-200 rounded-lg transition-colors text-sm font-medium"
              >
                Cancel
              </button>
              <button 
                onClick={handleSave}
                className="flex items-center gap-2 px-6 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-lg shadow-md transition-all text-sm font-medium"
              >
                <Save size={18} /> Save
              </button>
            </div>
          </div>
        )}

        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse min-w-[600px] md:min-w-full">
            <thead>
              <tr className="text-slate-500 text-xs md:text-sm border-b border-slate-200">
                <th className="py-3 px-3 md:px-4 font-medium">Name</th>
                <th className="py-3 px-3 md:px-4 font-medium">Position</th>
                <th className="py-3 px-3 md:px-4 font-medium">Department</th>
                <th className="py-3 px-3 md:px-4 font-medium text-right">Actions</th>
              </tr>
            </thead>
            <tbody>
              {employees.length === 0 ? (
                <tr>
                  <td colSpan={4} className="py-8 text-center text-slate-400 text-sm">
                    No employees found. Add one to get started.
                  </td>
                </tr>
              ) : (
                employees.map(emp => (
                  <tr key={emp.id} className="border-b border-slate-100 hover:bg-slate-50 transition-colors">
                    <td className="py-3 px-3 md:px-4 flex items-center gap-3">
                      <div className="w-8 h-8 rounded-full bg-blue-100 text-blue-600 flex items-center justify-center shrink-0">
                        <User size={16} />
                      </div>
                      <span className="font-medium text-slate-700 text-sm md:text-base">{emp.name}</span>
                    </td>
                    <td className="py-3 px-3 md:px-4 text-slate-600 text-sm">{emp.position}</td>
                    <td className="py-3 px-3 md:px-4 text-slate-600">
                        <span className="inline-block px-2 py-1 text-[10px] md:text-xs font-semibold bg-slate-100 text-slate-600 rounded-md">
                            {emp.department}
                        </span>
                    </td>
                    <td className="py-3 px-3 md:px-4 text-right">
                      <button 
                        onClick={() => { setFormData(emp); setIsEditing(true); }}
                        className="text-blue-600 hover:text-blue-800 mx-1 p-1 hover:bg-blue-50 rounded"
                      >
                        <Edit2 size={16} />
                      </button>
                      <button 
                        onClick={() => handleDelete(emp.id)}
                        className="text-red-500 hover:text-red-700 mx-1 p-1 hover:bg-red-50 rounded"
                      >
                        <Trash2 size={16} />
                      </button>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};