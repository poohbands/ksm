import React, { useState, useEffect } from 'react';
import { getWorkplaceConfig, saveWorkplaceConfig } from '../services/storageService';
import { WorkplaceConfig } from '../types';
import { MapPin, Save, Crosshair, Building2, Table, HelpCircle, ChevronDown, ChevronUp, Copy, Check, Clock } from 'lucide-react';

export const WorkplaceSettings: React.FC = () => {
  const [config, setConfig] = useState<WorkplaceConfig>({ lat: 0, lng: 0, name: '', googleSheetsUrl: '', lateThreshold: '09:00' });
  const [loading, setLoading] = useState(false);
  const [msg, setMsg] = useState<{ type: 'success' | 'error', text: string } | null>(null);
  const [showGuide, setShowGuide] = useState(false);
  const [copied, setCopied] = useState(false);

  useEffect(() => {
    const saved = getWorkplaceConfig();
    if (saved) setConfig({ ...config, ...saved });
  }, []);

  const handleGetCurrentLocation = () => {
    setLoading(true);
    if (!navigator.geolocation) {
      setMsg({ type: 'error', text: "Geolocation is not supported by your browser." });
      setLoading(false);
      return;
    }

    navigator.geolocation.getCurrentPosition(
      (position) => {
        setConfig({
          ...config,
          lat: position.coords.latitude,
          lng: position.coords.longitude
        });
        setMsg({ type: 'success', text: "Current location retrieved." });
        setLoading(false);
      },
      () => {
        setMsg({ type: 'error', text: "Unable to retrieve location." });
        setLoading(false);
      }
    );
  };

  const handleSave = () => {
    saveWorkplaceConfig(config);
    setMsg({ type: 'success', text: "System configuration saved successfully." });
    setTimeout(() => setMsg(null), 3000);
  };

  const scriptCode = `function doPost(e) {
  var sheet = SpreadsheetApp.getActiveSpreadsheet().getActiveSheet();
  var data = JSON.parse(e.postData.contents);
  
  // Create headers if sheet is empty
  if (sheet.getLastRow() === 0) {
    var headers = Object.keys(data[0]);
    sheet.appendRow(headers);
  }
  
  // Append new rows
  data.forEach(function(row) {
    var values = Object.values(row);
    sheet.appendRow(values);
  });
  
  return ContentService.createTextOutput("Success").setMimeType(ContentService.MimeType.TEXT);
}`;

  const copyToClipboard = () => {
    navigator.clipboard.writeText(scriptCode);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="max-w-3xl mx-auto space-y-6">
       <div className="bg-white p-4 md:p-6 rounded-xl shadow-sm border border-slate-200">
        <div className="flex items-center gap-3 mb-6 pb-6 border-b border-slate-100">
            <div className="p-3 bg-blue-100 text-blue-600 rounded-lg">
                <Building2 size={24} />
            </div>
            <div>
                <h2 className="text-lg md:text-xl font-bold text-slate-800">System Configuration</h2>
                <p className="text-slate-500 text-xs md:text-sm">Manage workplace location and external integrations.</p>
            </div>
        </div>

        <div className="space-y-8">
            {/* Location Section */}
            <div className="space-y-4">
                <h3 className="text-sm font-semibold text-slate-900 uppercase tracking-wider flex items-center gap-2">
                    <MapPin size={16} /> Location & Geofencing
                </h3>
                
                <div>
                    <label className="block text-sm font-medium text-slate-700 mb-1">Workplace Name</label>
                    <input
                        type="text"
                        className="w-full p-3 border border-slate-300 rounded-lg outline-none focus:ring-2 focus:ring-blue-500 text-base"
                        value={config.name || ''}
                        onChange={(e) => setConfig({ ...config, name: e.target.value })}
                        placeholder="e.g. Head Office"
                    />
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                        <label className="block text-sm font-medium text-slate-700 mb-1">Latitude</label>
                        <input
                            type="number"
                            className="w-full p-3 border border-slate-300 rounded-lg outline-none focus:ring-2 focus:ring-blue-500 bg-slate-50 text-base"
                            value={config.lat}
                            onChange={(e) => setConfig({ ...config, lat: parseFloat(e.target.value) })}
                        />
                    </div>
                    <div>
                        <label className="block text-sm font-medium text-slate-700 mb-1">Longitude</label>
                        <input
                            type="number"
                            className="w-full p-3 border border-slate-300 rounded-lg outline-none focus:ring-2 focus:ring-blue-500 bg-slate-50 text-base"
                            value={config.lng}
                            onChange={(e) => setConfig({ ...config, lng: parseFloat(e.target.value) })}
                        />
                    </div>
                </div>

                <div className="flex flex-col md:flex-row gap-3">
                    <button
                        onClick={handleGetCurrentLocation}
                        disabled={loading}
                        className="flex-1 flex items-center justify-center gap-2 px-4 py-3 bg-slate-100 text-slate-700 rounded-lg hover:bg-slate-200 transition-colors font-medium text-sm"
                    >
                        <Crosshair size={16} /> Use Current Location
                    </button>
                </div>

                <div className="bg-yellow-50 border border-yellow-100 rounded-lg p-3">
                    <p className="text-xs text-yellow-700">
                        Employees must be within <strong>100 meters</strong> of these coordinates to check in or out.
                    </p>
                </div>
            </div>

            <hr className="border-slate-100" />

            {/* Time Settings */}
            <div className="space-y-4">
                <h3 className="text-sm font-semibold text-slate-900 uppercase tracking-wider flex items-center gap-2">
                    <Clock size={16} /> Time & Attendance Rules
                </h3>
                
                <div>
                    <label className="block text-sm font-medium text-slate-700 mb-1">Late Arrival Threshold</label>
                    <div className="flex items-center gap-3">
                        <input
                            type="time"
                            className="p-3 border border-slate-300 rounded-lg outline-none focus:ring-2 focus:ring-blue-500 text-base"
                            value={config.lateThreshold || '09:00'}
                            onChange={(e) => setConfig({ ...config, lateThreshold: e.target.value })}
                        />
                        <span className="text-xs md:text-sm text-slate-500">Employees checking in after this time will be marked as "Late".</span>
                    </div>
                </div>
            </div>

            <hr className="border-slate-100" />

            {/* Google Sheets Integration */}
            <div className="space-y-4">
                <h3 className="text-sm font-semibold text-slate-900 uppercase tracking-wider flex items-center gap-2">
                    <Table size={16} /> Google Sheets Integration
                </h3>
                
                <div>
                    <label className="block text-sm font-medium text-slate-700 mb-1">Google Apps Script Web App URL</label>
                    <input
                        type="text"
                        className="w-full p-3 border border-slate-300 rounded-lg outline-none focus:ring-2 focus:ring-blue-500 font-mono text-sm"
                        value={config.googleSheetsUrl || ''}
                        onChange={(e) => setConfig({ ...config, googleSheetsUrl: e.target.value })}
                        placeholder="https://script.google.com/macros/s/..."
                    />
                    <p className="text-xs text-slate-500 mt-1">
                        Paste the Web App URL here to enable the "Sync to Google Sheets" button in Reports.
                    </p>
                </div>

                <div className="border border-indigo-100 bg-indigo-50 rounded-lg overflow-hidden">
                    <button 
                        onClick={() => setShowGuide(!showGuide)}
                        className="w-full flex items-center justify-between p-3 text-indigo-700 hover:bg-indigo-100 transition-colors"
                    >
                        <span className="flex items-center gap-2 text-sm font-semibold"><HelpCircle size={16} /> How to set up Google Sheets</span>
                        {showGuide ? <ChevronUp size={16} /> : <ChevronDown size={16} />}
                    </button>
                    
                    {showGuide && (
                        <div className="p-4 bg-white border-t border-indigo-100 text-sm space-y-3 text-slate-600">
                            <ol className="list-decimal pl-4 space-y-2">
                                <li>Create a new Google Sheet.</li>
                                <li>Go to <strong>Extensions</strong> &gt; <strong>Apps Script</strong>.</li>
                                <li>Delete any code there and paste the code below.</li>
                                <li>Click <strong>Deploy</strong> &gt; <strong>New deployment</strong>.</li>
                                <li>Select type: <strong>Web app</strong>.</li>
                                <li>Set "Who has access" to: <strong>Anyone</strong> (Important!).</li>
                                <li>Click <strong>Deploy</strong> and copy the <strong>Web app URL</strong>.</li>
                                <li>Paste the URL in the input field above and click Save.</li>
                            </ol>
                            
                            <div className="relative mt-2">
                                <pre className="bg-slate-900 text-slate-300 p-3 rounded-lg overflow-x-auto text-xs font-mono">
                                    {scriptCode}
                                </pre>
                                <button 
                                    onClick={copyToClipboard}
                                    className="absolute top-2 right-2 p-1.5 bg-white/10 hover:bg-white/20 rounded text-white transition-colors"
                                    title="Copy Code"
                                >
                                    {copied ? <Check size={14} className="text-emerald-400"/> : <Copy size={14} />}
                                </button>
                            </div>
                        </div>
                    )}
                </div>
            </div>

            {msg && (
                <div className={`p-3 rounded-lg text-sm flex items-center gap-2 ${msg.type === 'success' ? 'bg-emerald-50 text-emerald-600' : 'bg-red-50 text-red-600'}`}>
                    {msg.type === 'success' ? <Check size={16} /> : <Crosshair size={16} />}
                    {msg.text}
                </div>
            )}

            <button
                onClick={handleSave}
                className="w-full flex items-center justify-center gap-2 px-6 py-4 bg-blue-600 text-white rounded-xl hover:bg-blue-700 transition-colors font-bold shadow-md hover:shadow-lg transform active:scale-95"
            >
                <Save size={20} /> Save All Configuration
            </button>
        </div>
       </div>
    </div>
  );
};