import React, { useState, useEffect } from 'react';
import { getAttendance, getWorkplaceConfig, getEmployees } from '../services/storageService';
import { AttendanceRecord, Employee } from '../types';
import { Download, Search, MapPin, BrainCircuit, Loader2, Image as ImageIcon, X, Cloud, Check, Clock, UserX, Users, AlertTriangle } from 'lucide-react';
import * as XLSX from 'xlsx';
import { analyzeAttendance } from '../services/geminiService';

export const Reporting: React.FC = () => {
  const [records, setRecords] = useState<AttendanceRecord[]>([]);
  const [employees, setEmployees] = useState<Employee[]>([]);
  // Default to today for immediate dashboard utility
  const [filterDate, setFilterDate] = useState<string>(new Date().toISOString().split('T')[0]);
  const [aiAnalysis, setAiAnalysis] = useState<string | null>(null);
  const [analyzing, setAnalyzing] = useState(false);
  const [selectedImage, setSelectedImage] = useState<string | null>(null);
  const [lateThreshold, setLateThreshold] = useState<string>('09:00');
  
  // Google Sheet Sync State
  const [syncing, setSyncing] = useState(false);
  const [syncMsg, setSyncMsg] = useState<{type: 'success' | 'error', text: string} | null>(null);
  const [hasSheetUrl, setHasSheetUrl] = useState(false);

  useEffect(() => {
    loadData();
    const config = getWorkplaceConfig();
    if (config?.googleSheetsUrl) {
        setHasSheetUrl(true);
    }
    if (config?.lateThreshold) {
        setLateThreshold(config.lateThreshold);
    }
  }, []);

  const loadData = () => {
    const allRecords = getAttendance();
    // Sort by date desc
    allRecords.sort((a, b) => new Date(b.checkInTime).getTime() - new Date(a.checkInTime).getTime());
    setRecords(allRecords);
    setEmployees(getEmployees());
  };

  const filteredRecords = records.filter(r => {
    if (!filterDate) return true;
    return r.date === filterDate;
  });

  // --- Statistics Logic ---
  const isLate = (checkInTime: string) => {
    const checkInDate = new Date(checkInTime);
    const [thHour, thMin] = lateThreshold.split(':').map(Number);
    
    // Create a date object for the threshold on the same day as check-in
    const thresholdDate = new Date(checkInDate);
    thresholdDate.setHours(thHour, thMin, 0, 0);
    
    return checkInDate > thresholdDate;
  };

  const lateRecords = filteredRecords.filter(r => isLate(r.checkInTime));
  
  const getAbsentEmployees = () => {
    if (!filterDate) return [];
    const presentEmployeeIds = new Set(filteredRecords.map(r => r.employeeId));
    // Filter active employees who are NOT in the present set
    return employees.filter(e => e.status === 'active' && !presentEmployeeIds.has(e.id));
  };

  const absentEmployees = getAbsentEmployees();
  // -------------------------

  const formatThaiDateTime = (isoDate: string) => {
    return new Date(isoDate).toLocaleString('th-TH', {
        year: 'numeric',
        month: 'long',
        day: 'numeric',
        hour: '2-digit',
        minute: '2-digit',
        second: '2-digit',
        hour12: false
    });
  };

  // Helper for Excel Export: Date only
  const formatThaiDateOnly = (isoDate: string) => {
    return new Date(isoDate).toLocaleString('th-TH', {
        year: 'numeric',
        month: 'long',
        day: 'numeric',
    });
  };

  // Helper for Excel Export: Time only
  const formatThaiTimeOnly = (isoDate: string) => {
    return new Date(isoDate).toLocaleString('th-TH', {
        hour: '2-digit',
        minute: '2-digit',
        second: '2-digit',
        hour12: false
    });
  };

  const getExportData = () => {
    // Basic Records
    return filteredRecords.map(r => ({
      ID: r.employeeId,
      Name: r.employeeName,
      'Check In Date': formatThaiDateOnly(r.checkInTime),
      'Check In Time': formatThaiTimeOnly(r.checkInTime),
      'Status': isLate(r.checkInTime) ? 'LATE' : 'ON TIME',
      'Check In Latitude': r.checkInLocation.lat,
      'Check In Longitude': r.checkInLocation.lng,
      'Check Out Date': r.checkOutTime ? formatThaiDateOnly(r.checkOutTime) : '-',
      'Check Out Time': r.checkOutTime ? formatThaiTimeOnly(r.checkOutTime) : '-',
      'Check Out Latitude': r.checkOutLocation?.lat || '-',
      'Check Out Longitude': r.checkOutLocation?.lng || '-',
      'Device ID': r.deviceId,
      'Has Photo': r.checkInImageUrl ? 'Yes' : 'No'
    }));
  };

  const exportToExcel = () => {
    const dataToExport = getExportData();
    const ws = XLSX.utils.json_to_sheet(dataToExport);
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, "Attendance");
    XLSX.writeFile(wb, "AttendanceReport.xlsx");
  };

  const handleSyncToGoogleSheets = async () => {
    const config = getWorkplaceConfig();
    if (!config?.googleSheetsUrl) {
        setSyncMsg({ type: 'error', text: "Please configure Google Sheets URL in Settings first." });
        return;
    }

    setSyncing(true);
    setSyncMsg(null);

    try {
        const dataToSync = getExportData();
        
        await fetch(config.googleSheetsUrl, {
            method: 'POST',
            mode: 'no-cors', 
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify(dataToSync),
        });

        setSyncMsg({ type: 'success', text: "Data sent to Google Sheets successfully!" });
    } catch (err) {
        setSyncMsg({ type: 'error', text: "Failed to sync. Check internet connection or URL." });
    } finally {
        setSyncing(false);
        setTimeout(() => {
            if (syncMsg?.type === 'success') setSyncMsg(null);
        }, 3000);
    }
  };

  const handleAIAnalysis = async () => {
    setAnalyzing(true);
    const result = await analyzeAttendance(filteredRecords);
    setAiAnalysis(result);
    setAnalyzing(false);
  };

  return (
    <div className="space-y-4 md:space-y-6 animate-fade-in">
      {/* Image Modal */}
      {selectedImage && (
        <div className="fixed inset-0 bg-black/90 z-[60] flex items-center justify-center p-4" onClick={() => setSelectedImage(null)}>
            <div className="relative bg-white rounded-xl p-2 max-w-2xl w-full" onClick={e => e.stopPropagation()}>
                <button onClick={() => setSelectedImage(null)} className="absolute -top-4 -right-4 bg-white text-black rounded-full p-2 hover:bg-slate-200">
                    <X size={20} />
                </button>
                <img src={selectedImage} alt="Verification Evidence" className="w-full rounded-lg" />
            </div>
        </div>
      )}

      {/* Header & Controls */}
      <div className="bg-white p-4 md:p-6 rounded-xl shadow-sm border border-slate-200 flex flex-col xl:flex-row justify-between items-start xl:items-center gap-4">
        <div>
           <h2 className="text-xl font-bold text-slate-800">Attendance Dashboard</h2>
           <p className="text-slate-500 text-sm">Overview for: {filterDate ? new Date(filterDate).toLocaleDateString('th-TH', { dateStyle: 'full' }) : 'All Time'}</p>
        </div>
        
        <div className="flex flex-col w-full xl:w-auto gap-3">
          <input 
            type="date" 
            className="border border-slate-300 rounded-lg px-3 py-2.5 text-base text-slate-700 outline-none focus:ring-2 focus:ring-blue-500 w-full xl:w-auto"
            value={filterDate}
            onChange={(e) => setFilterDate(e.target.value)}
          />
          
          <div className="flex gap-2">
            <button 
                onClick={exportToExcel}
                className="flex-1 whitespace-nowrap flex items-center justify-center gap-2 bg-emerald-600 hover:bg-emerald-700 text-white px-4 py-2.5 rounded-lg font-medium transition-colors text-sm"
            >
                <Download size={18} /> Export Excel
            </button>
            
            {hasSheetUrl && (
                <button 
                    onClick={handleSyncToGoogleSheets}
                    disabled={syncing}
                    className="flex-1 whitespace-nowrap flex items-center justify-center gap-2 bg-blue-600 hover:bg-blue-700 text-white px-4 py-2.5 rounded-lg font-medium transition-colors disabled:opacity-70 disabled:cursor-not-allowed text-sm"
                >
                    {syncing ? <Loader2 size={18} className="animate-spin" /> : <Cloud size={18} />}
                    {syncing ? 'Syncing...' : 'Sync Sheets'}
                </button>
            )}
          </div>
        </div>
      </div>
      
      {syncMsg && (
        <div className={`p-3 rounded-lg flex items-center gap-2 text-sm ${syncMsg.type === 'success' ? 'bg-emerald-50 text-emerald-700 border border-emerald-200' : 'bg-red-50 text-red-700 border border-red-200'}`}>
            {syncMsg.type === 'success' ? <Check size={16} /> : <X size={16} />}
            {syncMsg.text}
        </div>
      )}

      {/* DASHBOARD STATISTICS (Only visible when a specific date is selected) */}
      {filterDate && (
          <div className="grid grid-cols-2 md:grid-cols-4 gap-3 md:gap-4 animate-fade-in-up">
              <div className="bg-white p-3 md:p-4 rounded-xl border border-slate-200 shadow-sm">
                  <div className="flex items-center gap-2 md:gap-3 mb-2">
                      <div className="p-1.5 md:p-2 bg-blue-100 text-blue-600 rounded-lg"><Users size={16} className="md:w-5 md:h-5" /></div>
                      <span className="text-slate-500 text-xs md:text-sm font-medium">Total Staff</span>
                  </div>
                  <div className="text-xl md:text-2xl font-bold text-slate-800">{employees.filter(e => e.status === 'active').length}</div>
              </div>

              <div className="bg-white p-3 md:p-4 rounded-xl border border-slate-200 shadow-sm">
                  <div className="flex items-center gap-2 md:gap-3 mb-2">
                      <div className="p-1.5 md:p-2 bg-emerald-100 text-emerald-600 rounded-lg"><Check size={16} className="md:w-5 md:h-5" /></div>
                      <span className="text-slate-500 text-xs md:text-sm font-medium">Present</span>
                  </div>
                  <div className="text-xl md:text-2xl font-bold text-slate-800">{filteredRecords.length}</div>
              </div>

              <div className="bg-white p-3 md:p-4 rounded-xl border border-orange-200 bg-orange-50 shadow-sm">
                  <div className="flex items-center gap-2 md:gap-3 mb-2">
                      <div className="p-1.5 md:p-2 bg-white text-orange-600 rounded-lg shadow-sm"><Clock size={16} className="md:w-5 md:h-5" /></div>
                      <span className="text-orange-800 text-xs md:text-sm font-medium">Late</span>
                  </div>
                  <div className="text-xl md:text-2xl font-bold text-orange-700">{lateRecords.length}</div>
                  <div className="text-[10px] md:text-xs text-orange-600 mt-1">After {lateThreshold}</div>
              </div>

              <div className="bg-white p-3 md:p-4 rounded-xl border border-red-200 bg-red-50 shadow-sm">
                  <div className="flex items-center gap-2 md:gap-3 mb-2">
                      <div className="p-1.5 md:p-2 bg-white text-red-600 rounded-lg shadow-sm"><UserX size={16} className="md:w-5 md:h-5" /></div>
                      <span className="text-red-800 text-xs md:text-sm font-medium">Absent</span>
                  </div>
                  <div className="text-xl md:text-2xl font-bold text-red-700">{absentEmployees.length}</div>
                  <div className="text-[10px] md:text-xs text-red-600 mt-1">Not checked in</div>
              </div>
          </div>
      )}

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4 md:gap-6">
          {/* LATE ARRIVALS LIST */}
          {filterDate && lateRecords.length > 0 && (
              <div className="bg-white rounded-xl shadow-sm border border-orange-200 overflow-hidden">
                  <div className="bg-orange-50 px-4 py-3 border-b border-orange-100 flex items-center gap-2">
                      <Clock size={16} className="text-orange-600"/>
                      <h3 className="font-semibold text-orange-800 text-sm md:text-base">Late Arrivals List</h3>
                  </div>
                  <div className="overflow-x-auto max-h-60 overflow-y-auto">
                      <table className="w-full text-left text-xs md:text-sm">
                          <thead className="bg-orange-50/50">
                              <tr>
                                  <th className="py-2 px-3 md:px-4 text-orange-900">Name</th>
                                  <th className="py-2 px-3 md:px-4 text-orange-900">Time</th>
                                  <th className="py-2 px-3 md:px-4 text-orange-900">Late By</th>
                              </tr>
                          </thead>
                          <tbody>
                              {lateRecords.map(r => {
                                  const time = new Date(r.checkInTime);
                                  const [thH, thM] = lateThreshold.split(':').map(Number);
                                  const threshold = new Date(time);
                                  threshold.setHours(thH, thM, 0, 0);
                                  const diffMins = Math.round((time.getTime() - threshold.getTime()) / 60000);
                                  
                                  return (
                                    <tr key={r.id} className="border-b border-orange-50 hover:bg-orange-50/30">
                                        <td className="py-2 px-3 md:px-4 font-medium">{r.employeeName}</td>
                                        <td className="py-2 px-3 md:px-4 text-slate-600">{time.toLocaleTimeString('th-TH')}</td>
                                        <td className="py-2 px-3 md:px-4 text-red-600 font-bold">+{diffMins} min</td>
                                    </tr>
                                  );
                              })}
                          </tbody>
                      </table>
                  </div>
              </div>
          )}

          {/* ABSENT LIST */}
          {filterDate && absentEmployees.length > 0 && (
              <div className="bg-white rounded-xl shadow-sm border border-red-200 overflow-hidden">
                   <div className="bg-red-50 px-4 py-3 border-b border-red-100 flex items-center gap-2">
                      <UserX size={16} className="text-red-600"/>
                      <h3 className="font-semibold text-red-800 text-sm md:text-base">Absent Employees</h3>
                  </div>
                  <div className="overflow-x-auto max-h-60 overflow-y-auto">
                      <table className="w-full text-left text-xs md:text-sm">
                          <thead className="bg-red-50/50">
                              <tr>
                                  <th className="py-2 px-3 md:px-4 text-red-900">Name</th>
                                  <th className="py-2 px-3 md:px-4 text-red-900">Department</th>
                                  <th className="py-2 px-3 md:px-4 text-red-900">Position</th>
                              </tr>
                          </thead>
                          <tbody>
                              {absentEmployees.map(e => (
                                  <tr key={e.id} className="border-b border-red-50 hover:bg-red-50/30">
                                      <td className="py-2 px-3 md:px-4 font-medium">{e.name}</td>
                                      <td className="py-2 px-3 md:px-4 text-slate-600">{e.department}</td>
                                      <td className="py-2 px-3 md:px-4 text-slate-600">{e.position}</td>
                                  </tr>
                              ))}
                          </tbody>
                      </table>
                  </div>
              </div>
          )}
      </div>

      {/* AI Analysis Section */}
      <div className="bg-gradient-to-r from-indigo-50 to-blue-50 p-4 md:p-6 rounded-xl border border-indigo-100">
        <div className="flex justify-between items-start mb-3">
            <div className="flex items-center gap-2 text-indigo-900 font-semibold">
                <BrainCircuit size={20} className="text-indigo-600" />
                <span className="text-sm md:text-base">AI Insight</span>
            </div>
            {!aiAnalysis && (
                <button 
                    onClick={handleAIAnalysis}
                    disabled={analyzing}
                    className="text-xs bg-indigo-600 hover:bg-indigo-700 text-white px-3 py-1.5 rounded-md transition-colors flex items-center gap-1"
                >
                    {analyzing ? <Loader2 size={12} className="animate-spin"/> : null}
                    {analyzing ? 'Analyzing...' : 'Analyze'}
                </button>
            )}
        </div>
        
        {aiAnalysis ? (
            <div className="prose prose-sm text-slate-700 bg-white/50 p-3 md:p-4 rounded-lg border border-indigo-100">
                <p className="whitespace-pre-line leading-relaxed text-sm">{aiAnalysis}</p>
                <button 
                    onClick={() => setAiAnalysis(null)} 
                    className="text-xs text-indigo-500 mt-2 hover:underline"
                >
                    Clear Analysis
                </button>
            </div>
        ) : (
            <p className="text-xs md:text-sm text-slate-500 italic">
                Use Gemini AI to detect punctuality trends and operational anomalies in your filtered data.
            </p>
        )}
      </div>

      {/* Table */}
      <div className="bg-white rounded-xl shadow-sm border border-slate-200 overflow-hidden">
        <div className="px-4 py-3 md:px-6 md:py-4 border-b border-slate-200 bg-slate-50 flex justify-between items-center">
             <h3 className="font-semibold text-slate-700 text-sm md:text-base">Detailed Records</h3>
             <span className="text-xs text-slate-500">{filteredRecords.length} records</span>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full text-left min-w-[600px] md:min-w-full">
            <thead className="bg-slate-50 border-b border-slate-200">
              <tr>
                <th className="py-3 px-3 md:px-4 font-medium text-slate-600 text-xs md:text-sm">Employee</th>
                <th className="py-3 px-3 md:px-4 font-medium text-slate-600 text-xs md:text-sm">Check In</th>
                <th className="py-3 px-3 md:px-4 font-medium text-slate-600 text-xs md:text-sm">Check Out</th>
                <th className="py-3 px-3 md:px-4 font-medium text-slate-600 text-xs md:text-sm">Location</th>
                <th className="py-3 px-3 md:px-4 font-medium text-slate-600 text-xs md:text-sm text-center">Evidence</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {filteredRecords.length === 0 ? (
                <tr>
                    <td colSpan={5} className="py-8 text-center text-slate-400 text-sm">No records found.</td>
                </tr>
              ) : (
                  filteredRecords.map((r) => {
                    const isLateRecord = isLate(r.checkInTime);
                    return (
                    <tr key={r.id} className={`transition-colors ${isLateRecord ? 'bg-orange-50/30 hover:bg-orange-50' : 'hover:bg-slate-50'}`}>
                      <td className="py-3 px-3 md:px-4">
                        <div className="font-medium text-slate-800 text-sm">{r.employeeName}</div>
                        <div className="text-[10px] text-slate-500">{new Date(r.date).toLocaleDateString('th-TH', { dateStyle: 'medium'})}</div>
                      </td>
                      <td className="py-3 px-3 md:px-4 text-xs md:text-sm">
                        <div className={`font-medium ${isLateRecord ? 'text-orange-600' : 'text-emerald-600'}`}>
                            {formatThaiDateTime(r.checkInTime)}
                        </div>
                        {isLateRecord && <span className="text-[10px] uppercase font-bold text-orange-500 bg-orange-100 px-1.5 py-0.5 rounded">Late</span>}
                      </td>
                      <td className="py-3 px-3 md:px-4 text-red-500 text-xs md:text-sm">
                        {r.checkOutTime 
                          ? formatThaiDateTime(r.checkOutTime)
                          : <span className="text-slate-400 italic">Active</span>
                        }
                      </td>
                      <td className="py-3 px-3 md:px-4 text-slate-500 text-xs">
                        <div className="flex flex-col gap-1">
                            <div className="flex items-center gap-1" title="Check-in Coords">
                                <MapPin size={10} className="text-emerald-500 shrink-0"/> 
                                <span>In: {r.checkInLocation.lat.toFixed(4)}, {r.checkInLocation.lng.toFixed(4)}</span>
                            </div>
                            {r.checkOutLocation && (
                                <div className="flex items-center gap-1" title="Check-out Coords">
                                    <MapPin size={10} className="text-red-500 shrink-0"/> 
                                    <span>Out: {r.checkOutLocation.lat.toFixed(4)}, {r.checkOutLocation.lng.toFixed(4)}</span>
                                </div>
                            )}
                        </div>
                      </td>
                      <td className="py-3 px-3 md:px-4">
                        <div className="flex justify-center gap-2">
                            {r.checkInImageUrl && (
                                <button onClick={() => setSelectedImage(r.checkInImageUrl || null)} className="relative group">
                                    <img src={r.checkInImageUrl} alt="In" className="w-8 h-8 md:w-10 md:h-10 rounded-full object-cover border-2 border-emerald-200 hover:border-emerald-500 transition-colors" />
                                    <span className="absolute -bottom-1 -right-1 bg-emerald-500 text-white text-[8px] px-1 rounded-full">IN</span>
                                </button>
                            )}
                            {r.checkOutImageUrl && (
                                <button onClick={() => setSelectedImage(r.checkOutImageUrl || null)} className="relative group">
                                    <img src={r.checkOutImageUrl} alt="Out" className="w-8 h-8 md:w-10 md:h-10 rounded-full object-cover border-2 border-red-200 hover:border-red-500 transition-colors" />
                                    <span className="absolute -bottom-1 -right-1 bg-red-500 text-white text-[8px] px-1 rounded-full">OUT</span>
                                </button>
                            )}
                        </div>
                      </td>
                    </tr>
                  )})
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};