export interface Employee {
  id: string;
  name: string;
  position: string;
  department: string;
  status: 'active' | 'inactive';
}

export interface AttendanceRecord {
  id: string;
  employeeId: string;
  employeeName: string;
  checkInTime: string; // ISO string
  checkOutTime?: string; // ISO string
  checkInLocation: { lat: number; lng: number };
  checkOutLocation?: { lat: number; lng: number };
  deviceId: string;
  date: string; // YYYY-MM-DD for grouping
  checkInImageUrl?: string; // Base64 image
  checkOutImageUrl?: string; // Base64 image
}

export interface DeviceLog {
  lastCheckInTimestamp: number; // epoch
  deviceId: string;
}

export interface WorkplaceConfig {
  lat: number;
  lng: number;
  name?: string;
  googleSheetsUrl?: string;
  lateThreshold?: string; // HH:mm format (e.g. "09:00")
}

export type ViewState = 'dashboard' | 'employees' | 'reports' | 'settings';

// AI Analysis Types
export interface DailySummary {
  totalPresent: number;
  lateArrivals: number;
  avgWorkHours: number;
  summaryText: string;
}