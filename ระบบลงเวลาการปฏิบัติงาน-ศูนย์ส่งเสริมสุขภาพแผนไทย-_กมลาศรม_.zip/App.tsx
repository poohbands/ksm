import React, { useState, useEffect, useRef } from 'react';
import { Employee, AttendanceRecord, ViewState } from './types';
import { 
  getEmployees, 
  saveAttendance, 
  canDeviceCheckIn, 
  recordDeviceUsage, 
  getDeviceId,
  getActiveSession,
  getWorkplaceConfig,
  calculateDistanceMeters
} from './services/storageService';
import { EmployeeManager } from './components/EmployeeManager';
import { Reporting } from './components/Reporting';
import { AdminLogin } from './components/AdminLogin';
import { WorkplaceSettings } from './components/WorkplaceSettings';
import { 
  LayoutDashboard, 
  Users, 
  FileSpreadsheet, 
  MapPin, 
  LogIn, 
  LogOut, 
  AlertTriangle,
  Clock,
  CheckCircle,
  Camera,
  RefreshCw,
  Lock,
  Unlock,
  Shield,
  Settings
} from 'lucide-react';

const App: React.FC = () => {
  const [view, setView] = useState<ViewState>('dashboard');
  const [employees, setEmployees] = useState<Employee[]>([]);
  const [selectedEmpId, setSelectedEmpId] = useState<string>('');
  const [loading, setLoading] = useState(false);
  const [msg, setMsg] = useState<{ type: 'success' | 'error', text: string } | null>(null);
  const [currentSession, setCurrentSession] = useState<AttendanceRecord | undefined>(undefined);
  
  // Real-time clock state
  const [currentTime, setCurrentTime] = useState(new Date());

  // Admin State
  const [isAdminLoggedIn, setIsAdminLoggedIn] = useState(false);

  // Camera Refs
  const videoRef = useRef<HTMLVideoElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [cameraActive, setCameraActive] = useState(false);
  const [cameraError, setCameraError] = useState<string>('');

  useEffect(() => {
    setEmployees(getEmployees());
    
    // Clock interval
    const timer = setInterval(() => setCurrentTime(new Date()), 1000);
    return () => clearInterval(timer);
  }, [view]);

  useEffect(() => {
    if (selectedEmpId) {
      const session = getActiveSession(selectedEmpId);
      setCurrentSession(session);
      setMsg(null);
      startCamera();
    } else {
        setCurrentSession(undefined);
        stopCamera();
    }
    // Cleanup on unmount or change
    return () => {
        stopCamera();
    };
  }, [selectedEmpId]);

  const startCamera = async () => {
    setCameraError('');
    try {
        const stream = await navigator.mediaDevices.getUserMedia({ 
            video: { facingMode: 'user', width: { ideal: 640 }, height: { ideal: 480 } } 
        });
        if (videoRef.current) {
            videoRef.current.srcObject = stream;
            setCameraActive(true);
        }
    } catch (err) {
        console.error("Camera Error:", err);
        setCameraError("Unable to access camera. Please allow camera permissions to check in.");
        setCameraActive(false);
    }
  };

  const stopCamera = () => {
    if (videoRef.current && videoRef.current.srcObject) {
        const stream = videoRef.current.srcObject as MediaStream;
        stream.getTracks().forEach(track => track.stop());
        videoRef.current.srcObject = null;
        setCameraActive(false);
    }
  };

  const capturePhoto = (): string | null => {
    if (videoRef.current && canvasRef.current) {
        const video = videoRef.current;
        const canvas = canvasRef.current;
        canvas.width = video.videoWidth;
        canvas.height = video.videoHeight;
        const ctx = canvas.getContext('2d');
        if (ctx) {
            // Draw video frame to canvas
            ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
            // Add timestamp overlay
            ctx.font = '16px Arial';
            ctx.fillStyle = 'white';
            ctx.shadowColor = 'black';
            ctx.shadowBlur = 4;
            const thaiDate = new Date().toLocaleString('th-TH', { 
                year: 'numeric', month: 'short', day: 'numeric', 
                hour: '2-digit', minute: '2-digit', second: '2-digit' 
            });
            ctx.fillText(thaiDate, 10, canvas.height - 20);
            return canvas.toDataURL('image/jpeg', 0.8);
        }
    }
    return null;
  };

  const getCurrentLocation = (): Promise<{lat: number, lng: number}> => {
    return new Promise((resolve, reject) => {
      if (!navigator.geolocation) {
        reject("Geolocation is not supported by this browser.");
      }
      navigator.geolocation.getCurrentPosition(
        (position) => {
          resolve({
            lat: position.coords.latitude,
            lng: position.coords.longitude
          });
        },
        () => {
          reject("Unable to retrieve your location. Permission needed.");
        }
      );
    });
  };

  const validateDistance = (userLoc: {lat: number, lng: number}): { valid: boolean; dist: number } => {
    const workplace = getWorkplaceConfig();
    if (!workplace) return { valid: true, dist: 0 }; // If no config, allow it (or force config depending on requirement)
    
    const dist = calculateDistanceMeters(userLoc.lat, userLoc.lng, workplace.lat, workplace.lng);
    return { valid: dist <= 100, dist };
  };

  const formatThaiTime = (dateStr: string | Date) => {
    return new Date(dateStr).toLocaleString('th-TH', {
        year: 'numeric', month: 'long', day: 'numeric', 
        hour: '2-digit', minute: '2-digit', second: '2-digit',
        hour12: false
    });
  };

  const handleCheckIn = async () => {
    if (!selectedEmpId) return;

    // Requirement #7: Device Lock
    const deviceCheck = canDeviceCheckIn();
    if (!deviceCheck.allowed) {
        const hoursLeft = Math.ceil((deviceCheck.waitTime || 0) / (1000 * 60 * 60));
        setMsg({ 
            type: 'error', 
            text: `Device Locked: This device has been used for a check-in recently. Try again in ${hoursLeft} hours.` 
        });
        return;
    }

    if (!cameraActive) {
        setMsg({ type: 'error', text: "Camera required for identity verification." });
        return;
    }

    setLoading(true);
    setMsg(null);

    try {
      // 1. Get Location
      const location = await getCurrentLocation();

      // 2. Validate Distance (Geofencing)
      const { valid, dist } = validateDistance(location);
      if (!valid) {
          throw new Error(`ไม่สามารถบันทึกได้เนื่องจากพิกัดอยู่ห่างจากสถานที่ทำงานเกิน 100 เมตร (ปัจจุบัน: ${Math.round(dist)} เมตร)`);
      }

      // 3. Capture Photo
      const photoData = capturePhoto();
      if (!photoData) throw new Error("Failed to capture verification photo.");
      
      const emp = employees.find(e => e.id === selectedEmpId);
      if (!emp) throw new Error("Employee not found");

      const now = new Date();
      const record: AttendanceRecord = {
        id: crypto.randomUUID(),
        employeeId: emp.id,
        employeeName: emp.name,
        checkInTime: now.toISOString(),
        checkInLocation: location,
        deviceId: getDeviceId(),
        date: now.toISOString().split('T')[0],
        checkInImageUrl: photoData
      };

      saveAttendance(record);
      recordDeviceUsage(); // Lock device
      
      setCurrentSession(record);
      setMsg({ type: 'success', text: `ท่านอยู่ในระยะห่างที่กำหนด สามารถบันทึกข้อมูลได้ (Checked In at ${formatThaiTime(now)})` });
    } catch (err: any) {
      setMsg({ type: 'error', text: err.toString() });
    } finally {
      setLoading(false);
    }
  };

  const handleCheckOut = async () => {
    if (!currentSession) return;
    
    // Requirement #6: 12h rule
    const checkInDate = new Date(currentSession.checkInTime);
    const now = new Date();
    const diffHours = (now.getTime() - checkInDate.getTime()) / (1000 * 60 * 60);

    if (diffHours > 12) {
         setMsg({ 
            type: 'error', 
            text: "Session Expired: You did not check out within 12 hours of checking in. Please contact admin." 
        });
        return;
    }

    if (!cameraActive) {
        setMsg({ type: 'error', text: "Camera required for identity verification." });
        return;
    }

    setLoading(true);
    try {
        // 1. Get Location
        const location = await getCurrentLocation();

        // 2. Validate Distance
        const { valid, dist } = validateDistance(location);
        if (!valid) {
             throw new Error(`ไม่สามารถบันทึกได้เนื่องจากพิกัดอยู่ห่างจากสถานที่ทำงานเกิน 100 เมตร (ปัจจุบัน: ${Math.round(dist)} เมตร)`);
        }

        // 3. Capture Photo
        const photoData = capturePhoto();
        if (!photoData) throw new Error("Failed to capture verification photo.");

        const updatedRecord: AttendanceRecord = {
            ...currentSession,
            checkOutTime: new Date().toISOString(),
            checkOutLocation: location,
            checkOutImageUrl: photoData
        };
        saveAttendance(updatedRecord);
        setCurrentSession(undefined);
        setMsg({ type: 'success', text: `ท่านอยู่ในระยะห่างที่กำหนด สามารถบันทึกข้อมูลได้ (Checked Out Successfully at ${formatThaiTime(new Date())})` });
    } catch (err: any) {
        setMsg({ type: 'error', text: err.toString() });
    } finally {
        setLoading(false);
    }
  };

  const handleAdminLogout = () => {
      setIsAdminLoggedIn(false);
      setView('dashboard');
  };

  const SidebarItem = ({ id, label, icon: Icon, restricted }: any) => (
    <button
      onClick={() => setView(id)}
      className={`w-full flex items-center gap-3 px-4 py-3 rounded-lg transition-all ${
        view === id ? 'bg-blue-600 text-white shadow-md' : 'text-slate-400 hover:bg-slate-800 hover:text-white'
      }`}
    >
      <Icon size={20} />
      <span className="font-medium flex-1 text-left">{label}</span>
      {restricted && !isAdminLoggedIn && <Lock size={14} className="opacity-50" />}
      {restricted && isAdminLoggedIn && <Unlock size={14} className="text-emerald-500" />}
    </button>
  );

  return (
    // h-[100dvh] ensures it fits mobile screens perfectly including URL bars
    <div className="flex h-[100dvh] bg-slate-50 overflow-hidden">
      {/* Desktop Sidebar */}
      <aside className="w-64 bg-slate-900 text-white flex flex-col hidden md:flex transition-all shadow-xl z-20">
        <div className="p-6 border-b border-slate-800">
            <h1 className="text-2xl font-bold tracking-tight text-blue-400">GeoTime<span className="text-white">Pro</span></h1>
            <p className="text-xs text-slate-500 mt-1">Enterprise Attendance</p>
        </div>
        <nav className="flex-1 p-4 space-y-2">
            <SidebarItem id="dashboard" label="Check In/Out" icon={LayoutDashboard} />
            <div className="pt-4 pb-2 px-2 text-xs font-semibold text-slate-500 uppercase tracking-wider">Admin Zone</div>
            <SidebarItem id="employees" label="Employees" icon={Users} restricted={true} />
            <SidebarItem id="reports" label="Reports" icon={FileSpreadsheet} restricted={true} />
            <SidebarItem id="settings" label="Settings" icon={Settings} restricted={true} />
        </nav>
        <div className="p-4 border-t border-slate-800 text-xs text-slate-500 text-center">
            {isAdminLoggedIn ? (
                <button 
                    onClick={handleAdminLogout} 
                    className="flex items-center justify-center gap-2 w-full py-2 bg-red-900/30 text-red-400 hover:bg-red-900/50 rounded-lg transition-colors"
                >
                    <LogOut size={14} /> Admin Logout
                </button>
            ) : (
                <div className="flex items-center justify-center gap-2 opacity-50">
                    <Shield size={12} /> Secure System
                </div>
            )}
        </div>
      </aside>

      {/* Mobile Nav - Fixed Bottom */}
      <div className="md:hidden fixed bottom-0 left-0 right-0 bg-slate-900/95 backdrop-blur-md text-white flex justify-around p-2 pt-3 pb-[max(0.75rem,env(safe-area-inset-bottom))] z-50 shadow-[0_-4px_6px_-1px_rgba(0,0,0,0.1)] border-t border-slate-800">
        <button onClick={() => setView('dashboard')} className={`flex flex-col items-center gap-1 p-2 rounded-lg transition-colors ${view === 'dashboard' ? 'text-blue-400 bg-slate-800' : 'text-slate-400'}`}>
            <LayoutDashboard size={20} />
            <span className="text-[10px]">Home</span>
        </button>
        <button onClick={() => setView('employees')} className={`relative flex flex-col items-center gap-1 p-2 rounded-lg transition-colors ${view === 'employees' ? 'text-blue-400 bg-slate-800' : 'text-slate-400'}`}>
            <div className="relative">
                <Users size={20} />
                {!isAdminLoggedIn && <div className="absolute -top-1 -right-1 bg-slate-700 rounded-full p-[2px]"><Lock size={8}/></div>}
            </div>
            <span className="text-[10px]">Staff</span>
        </button>
        <button onClick={() => setView('reports')} className={`relative flex flex-col items-center gap-1 p-2 rounded-lg transition-colors ${view === 'reports' ? 'text-blue-400 bg-slate-800' : 'text-slate-400'}`}>
             <div className="relative">
                <FileSpreadsheet size={20} />
                {!isAdminLoggedIn && <div className="absolute -top-1 -right-1 bg-slate-700 rounded-full p-[2px]"><Lock size={8}/></div>}
             </div>
            <span className="text-[10px]">Reports</span>
        </button>
        <button onClick={() => setView('settings')} className={`relative flex flex-col items-center gap-1 p-2 rounded-lg transition-colors ${view === 'settings' ? 'text-blue-400 bg-slate-800' : 'text-slate-400'}`}>
             <div className="relative">
                <Settings size={20} />
                {!isAdminLoggedIn && <div className="absolute -top-1 -right-1 bg-slate-700 rounded-full p-[2px]"><Lock size={8}/></div>}
             </div>
            <span className="text-[10px]">Config</span>
        </button>
      </div>

      {/* Main Content */}
      <main className="flex-1 overflow-y-auto p-4 md:p-8 pb-32 md:pb-8 w-full">
        {view === 'dashboard' && (
          <div className="max-w-xl mx-auto space-y-6 animate-fade-in-up">
            
            <div className="text-center space-y-2 mb-6 md:mb-8 mt-2 md:mt-0">
                <h2 className="text-xl md:text-3xl font-bold text-slate-800 leading-snug">
                    ระบบลงเวลาการปฏิบัติงาน<br className="block"/> ศูนย์ส่งเสริมสุขภาพแผนไทย "กมลาศรม"
                </h2>
                
                {/* Real-time Clock */}
                <div className="inline-flex items-center gap-2 bg-blue-50 text-blue-700 px-4 py-2 rounded-full font-medium border border-blue-100 shadow-sm mt-3 animate-fade-in text-sm md:text-base">
                    <Clock size={16} />
                    <span>
                        {currentTime.toLocaleString('th-TH', {
                            weekday: 'short',
                            day: 'numeric',
                            month: 'short',
                            year: 'numeric',
                            hour: '2-digit',
                            minute: '2-digit',
                            second: '2-digit',
                        })}
                    </span>
                </div>
            </div>

            <div className="bg-white p-5 md:p-8 rounded-2xl shadow-lg border border-slate-100">
                <div className="space-y-6">
                    <div>
                        <label className="block text-sm font-medium text-slate-700 mb-2">Select Employee</label>
                        <select 
                            className="w-full p-3.5 border border-slate-200 rounded-xl bg-slate-50 focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none transition-all text-base appearance-none"
                            value={selectedEmpId}
                            onChange={(e) => setSelectedEmpId(e.target.value)}
                        >
                            <option value="">-- Select your name --</option>
                            {employees.map(e => (
                                <option key={e.id} value={e.id}>{e.name} - {e.position}</option>
                            ))}
                        </select>
                    </div>

                    {msg && (
                        <div className={`p-4 rounded-lg flex items-start gap-3 ${msg.type === 'success' ? 'bg-emerald-50 text-emerald-700 border border-emerald-100' : 'bg-red-50 text-red-700 border border-red-100'}`}>
                             {msg.type === 'error' ? <AlertTriangle className="shrink-0 mt-0.5" size={18} /> : <CheckCircle className="shrink-0 mt-0.5" size={18} />}
                             <p className="font-medium text-sm leading-snug">{msg.text}</p>
                        </div>
                    )}

                    {selectedEmpId && (
                        <div className="pt-4 border-t border-slate-100 animate-fade-in">
                            {/* Camera Preview */}
                            <div className="mb-6 relative bg-black rounded-xl overflow-hidden aspect-[4/3] md:aspect-video flex items-center justify-center shadow-inner">
                                {!cameraActive && !cameraError && <div className="text-white flex flex-col items-center gap-2"><RefreshCw className="animate-spin text-blue-400"/> <span className="text-sm">Starting Camera...</span></div>}
                                {cameraError && <div className="text-red-400 p-4 text-center text-sm">{cameraError}</div>}
                                <video 
                                    ref={videoRef} 
                                    autoPlay 
                                    playsInline 
                                    muted 
                                    className={`w-full h-full object-cover ${cameraActive ? 'opacity-100' : 'opacity-0'}`}
                                />
                                <canvas ref={canvasRef} className="hidden" />
                                
                                <div className="absolute top-3 right-3 bg-black/50 text-white text-[10px] px-2 py-1 rounded-full backdrop-blur-sm flex items-center gap-1">
                                    <Camera size={10} /> Live
                                </div>
                            </div>

                            {currentSession ? (
                                <div className="space-y-4">
                                    <div className="flex items-center justify-between bg-blue-50 p-4 rounded-lg border border-blue-100">
                                        <div>
                                            <p className="text-[10px] font-bold text-blue-600 uppercase tracking-wider">Current Status</p>
                                            <p className="text-lg font-bold text-slate-800 mt-0.5">Checked In</p>
                                            <p className="text-sm text-slate-500 mt-1 flex items-center gap-1">
                                                <Clock size={14} /> {formatThaiTime(currentSession.checkInTime)}
                                            </p>
                                        </div>
                                        <div className="h-10 w-10 rounded-full bg-blue-100 flex items-center justify-center text-blue-600 shadow-sm">
                                            <MapPin size={20} />
                                        </div>
                                    </div>
                                    <button 
                                        onClick={handleCheckOut}
                                        disabled={loading || !cameraActive}
                                        className={`w-full py-4 rounded-xl font-bold text-lg shadow-lg shadow-red-200 transform active:scale-95 transition-all flex items-center justify-center gap-2
                                            ${(loading || !cameraActive) ? 'bg-slate-300 cursor-not-allowed' : 'bg-red-500 hover:bg-red-600 text-white'}
                                        `}
                                    >
                                        {loading ? 'Processing...' : <><LogOut size={22}/> Check Out</>}
                                    </button>
                                </div>
                            ) : (
                                <button 
                                    onClick={handleCheckIn}
                                    disabled={loading || !cameraActive}
                                    className={`w-full py-4 rounded-xl font-bold text-lg shadow-lg shadow-blue-200 transform active:scale-95 transition-all flex items-center justify-center gap-2
                                        ${(loading || !cameraActive) ? 'bg-slate-300 cursor-not-allowed' : 'bg-blue-600 hover:bg-blue-700 text-white'}
                                    `}
                                >
                                    {loading ? 'Verifying...' : <><LogIn size={22}/> Check In</>}
                                </button>
                            )}
                        </div>
                    )}
                </div>
            </div>
            
            <div className="flex justify-center gap-6 text-slate-400 text-xs md:text-sm">
                <div className="flex items-center gap-1.5">
                    <MapPin size={14} /> GPS Recorded
                </div>
                <div className="flex items-center gap-1.5">
                    <Camera size={14} /> Face Verified
                </div>
            </div>

          </div>
        )}

        {view === 'employees' && (
            isAdminLoggedIn ? <EmployeeManager /> : <AdminLogin onLogin={() => setIsAdminLoggedIn(true)} />
        )}
        
        {view === 'reports' && (
            isAdminLoggedIn ? <Reporting /> : <AdminLogin onLogin={() => setIsAdminLoggedIn(true)} />
        )}

        {view === 'settings' && (
            isAdminLoggedIn ? <WorkplaceSettings /> : <AdminLogin onLogin={() => setIsAdminLoggedIn(true)} />
        )}
      </main>
    </div>
  );
};

export default App;