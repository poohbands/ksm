import { GoogleGenAI } from "@google/genai";
import { AttendanceRecord } from "../types";

const getAIClient = () => {
  if (!process.env.API_KEY) return null;
  return new GoogleGenAI({ apiKey: process.env.API_KEY });
};

export const analyzeAttendance = async (records: AttendanceRecord[]): Promise<string> => {
  const client = getAIClient();
  if (!client) return "API Key not configured. Unable to generate AI analysis.";

  // Prepare a lightweight summary for the AI to process to save tokens
  const summaryData = records.map(r => ({
    name: r.employeeName,
    date: r.date,
    in: r.checkInTime ? new Date(r.checkInTime).toLocaleTimeString() : 'N/A',
    out: r.checkOutTime ? new Date(r.checkOutTime).toLocaleTimeString() : 'N/A',
    locationMatch: r.checkOutLocation ? 'Yes' : 'Pending'
  }));

  const prompt = `
    Analyze the following attendance data for a company. 
    Provide a professional, concise summary (max 3 bullet points) focusing on:
    1. Overall attendance trends (punctuality).
    2. Any anomalies (e.g., very late check-ins or missing check-outs).
    3. A brief operational recommendation.

    Data: ${JSON.stringify(summaryData.slice(0, 50))} 
    (Note: showing last 50 records for brevity)
  `;

  try {
    const response = await client.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: prompt,
    });
    return response.text || "No analysis generated.";
  } catch (error) {
    console.error("Gemini Analysis Failed:", error);
    return "Failed to generate analysis. Please try again later.";
  }
};
