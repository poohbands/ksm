import { Employee, AttendanceRecord, DeviceLog, WorkplaceConfig } from '../types';

const KEYS = {
  EMPLOYEES: 'geotime_employees',
  ATTENDANCE: 'geotime_attendance',
  DEVICE_LOG: 'geotime_device_log',
  DEVICE_ID: 'geotime_device_uuid',
  WORKPLACE: 'geotime_workplace_config'
};

// --- Initial Sample Data ---
const SAMPLE_EMPLOYEES: Employee[] = [
    { id: 'emp01', name: 'Somchai Jai-dee', position: 'General Manager', department: 'Management', status: 'active' },
    { id: 'emp02', name: 'Somsri Rak-ngan', position: 'HR Manager', department: 'Human Resources', status: 'active' },
    { id: 'emp03', name: 'Mana Mee-ngern', position: 'Senior Developer', department: 'IT Department', status: 'active' },
    { id: 'emp04', name: 'Manee Mee-ta', position: 'UX/UI Designer', department: 'IT Department', status: 'active' },
    { id: 'emp05', name: 'Piti Pa-pay', position: 'Sales Executive', department: 'Sales', status: 'active' },
    { id: 'emp06', name: 'Chujai Rak-chat', position: 'Chief Accountant', department: 'Finance', status: 'active' },
    { id: 'emp07', name: 'Veera Khem-khaeng', position: 'Security Head', department: 'Security', status: 'active' },
    { id: 'emp08', name: 'Suda Suay-sai', position: 'Receptionist', department: 'Administration', status: 'active' },
    { id: 'emp09', name: 'Thong-dee Mee-sook', position: 'Logistics Driver', department: 'Logistics', status: 'active' },
    { id: 'emp10', name: 'Boon-mee Rak-dee', position: 'Facility Staff', department: 'Maintenance', status: 'active' },
];

const generateSampleAttendance = (): AttendanceRecord[] => {
    const records: AttendanceRecord[] = [];
    const today = new Date();
    const yesterday = new Date(today);
    yesterday.setDate(yesterday.getDate() - 1);
    
    // Sample Base Location (Bangkok)
    const baseLat = 13.7563;
    const baseLng = 100.5018;

    // Generate records for yesterday (Complete sessions) and today (Some active)
    [yesterday, today].forEach((dateObj, dayIndex) => {
        const dateStr = dateObj.toISOString().split('T')[0];
        const isYesterday = dayIndex === 0;

        SAMPLE_EMPLOYEES.forEach((emp, index) => {
            // Random check-in time between 07:30 and 09:30
            const checkInHour = 7;
            const checkInMinute = 30 + Math.floor(Math.random() * 120); // Random minute offset
            const checkInTime = new Date(dateObj);
            checkInTime.setHours(checkInHour, checkInMinute, Math.floor(Math.random() * 60)); // Randomized seconds

            // Determine if check-out exists
            let checkOutTime: Date | undefined = undefined;
            
            // If yesterday, everyone checked out. If today, some might still be working.
            if (isYesterday || (index % 2 === 0 && new Date().getHours() > 12)) {
                const checkOutHour = 17 + Math.floor(Math.random() * 3); // 17:00 - 19:00
                const checkOutMinute = Math.floor(Math.random() * 60);
                checkOutTime = new Date(dateObj);
                checkOutTime.setHours(checkOutHour, checkOutMinute, Math.floor(Math.random() * 60));
            }

            records.push({
                id: `auto-${emp.id}-${dateStr}`,
                employeeId: emp.id,
                employeeName: emp.name,
                checkInTime: checkInTime.toISOString(),
                checkOutTime: checkOutTime ? checkOutTime.toISOString() : undefined,
                checkInLocation: { 
                    lat: baseLat + (Math.random() * 0.002 - 0.001), 
                    lng: baseLng + (Math.random() * 0.002 - 0.001) 
                },
                checkOutLocation: checkOutTime ? { 
                    lat: baseLat + (Math.random() * 0.002 - 0.001), 
                    lng: baseLng + (Math.random() * 0.002 - 0.001) 
                } : undefined,
                deviceId: `device-${Math.floor(Math.random() * 1000)}`,
                date: dateStr,
                // Note: Sample data doesn't have real images, but the system handles undefined images gracefully
                checkInImageUrl: undefined,
                checkOutImageUrl: undefined
            });
        });
    });

    return records;
};

// --- Device ID Management (Simulating MAC Address) ---
export const getDeviceId = (): string => {
  let id = localStorage.getItem(KEYS.DEVICE_ID);
  if (!id) {
    id = crypto.randomUUID();
    localStorage.setItem(KEYS.DEVICE_ID, id);
  }
  return id;
};

// --- Device Usage Restrictions (Requirement #7) ---
export const canDeviceCheckIn = (): { allowed: boolean; waitTime?: number } => {
  const logStr = localStorage.getItem(KEYS.DEVICE_LOG);
  if (!logStr) return { allowed: true };

  const log: DeviceLog = JSON.parse(logStr);
  const now = Date.now();
  const twelveHoursMs = 12 * 60 * 60 * 1000;
  
  // If the last check-in on this device was less than 12 hours ago
  if (now - log.lastCheckInTimestamp < twelveHoursMs) {
    const remaining = twelveHoursMs - (now - log.lastCheckInTimestamp);
    return { allowed: false, waitTime: remaining };
  }

  return { allowed: true };
};

export const recordDeviceUsage = () => {
  const log: DeviceLog = {
    deviceId: getDeviceId(),
    lastCheckInTimestamp: Date.now()
  };
  localStorage.setItem(KEYS.DEVICE_LOG, JSON.stringify(log));
};

// --- Employee CRUD ---
export const getEmployees = (): Employee[] => {
  const data = localStorage.getItem(KEYS.EMPLOYEES);
  if (!data) {
      // Auto-seed with sample data if empty
      localStorage.setItem(KEYS.EMPLOYEES, JSON.stringify(SAMPLE_EMPLOYEES));
      return SAMPLE_EMPLOYEES;
  }
  return JSON.parse(data);
};

export const saveEmployee = (employee: Employee) => {
  const employees = getEmployees();
  const index = employees.findIndex(e => e.id === employee.id);
  if (index >= 0) {
    employees[index] = employee;
  } else {
    employees.push(employee);
  }
  localStorage.setItem(KEYS.EMPLOYEES, JSON.stringify(employees));
};

export const deleteEmployee = (id: string) => {
  const employees = getEmployees().filter(e => e.id !== id);
  localStorage.setItem(KEYS.EMPLOYEES, JSON.stringify(employees));
};

// --- Attendance CRUD ---
export const getAttendance = (): AttendanceRecord[] => {
  const data = localStorage.getItem(KEYS.ATTENDANCE);
  if (!data) {
      // Auto-seed with sample attendance if empty
      const samples = generateSampleAttendance();
      localStorage.setItem(KEYS.ATTENDANCE, JSON.stringify(samples));
      return samples;
  }
  return JSON.parse(data);
};

export const saveAttendance = (record: AttendanceRecord) => {
  const list = getAttendance();
  const index = list.findIndex(r => r.id === record.id);
  if (index >= 0) {
    list[index] = record;
  } else {
    list.push(record);
  }
  localStorage.setItem(KEYS.ATTENDANCE, JSON.stringify(list));
};

export const getActiveSession = (employeeId: string): AttendanceRecord | undefined => {
  const records = getAttendance();
  // Find a record for this employee that has no check-out time
  // AND was created within the last 24 hours (sanity check, though req #6 handles 12h rule)
  return records.find(r => 
    r.employeeId === employeeId && 
    !r.checkOutTime
  );
};

// --- Workplace Configuration & Geofencing ---

export const saveWorkplaceConfig = (config: WorkplaceConfig) => {
  localStorage.setItem(KEYS.WORKPLACE, JSON.stringify(config));
};

export const getWorkplaceConfig = (): WorkplaceConfig | null => {
  const data = localStorage.getItem(KEYS.WORKPLACE);
  if (data) {
    return JSON.parse(data);
  }
  // Default Sample location (Bangkok) if not set, to match sample data
  return { lat: 13.7563, lng: 100.5018, name: "Headquarters (Default)" };
};

// Haversine formula to calculate distance in meters
export const calculateDistanceMeters = (lat1: number, lon1: number, lat2: number, lon2: number): number => {
  const R = 6371e3; // metres
  const φ1 = lat1 * Math.PI/180; // φ, λ in radians
  const φ2 = lat2 * Math.PI/180;
  const Δφ = (lat2-lat1) * Math.PI/180;
  const Δλ = (lon2-lon1) * Math.PI/180;

  const a = Math.sin(Δφ/2) * Math.sin(Δφ/2) +
            Math.cos(φ1) * Math.cos(φ2) *
            Math.sin(Δλ/2) * Math.sin(Δλ/2);
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a));

  return R * c; // in meters
};